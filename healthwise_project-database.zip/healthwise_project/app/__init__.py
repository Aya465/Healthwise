from flask import Flask

def create_app():
    app = Flask(__name__)
    app.secret_key = 'your_secret_key'

    from app.routes.auth_routes import auth_bp
    from app.routes.symptom_routes import symptom_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(symptom_bp)

    return app