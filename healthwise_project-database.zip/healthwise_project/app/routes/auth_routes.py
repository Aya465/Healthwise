from flask import Blueprint, render_template, request, redirect, session
from config import get_connection
from flask import send_file
from app.report_generator import generate_user_report

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                       (username, email, password))
        conn.commit()
        conn.close()

        return redirect('/auth/login')

    return render_template('auth/register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']
            # بعد تسجيل الدخول نحوله إلى لوحة التحكم مباشرةً
            return redirect('/symptom/dashboard')
        else:
            return "Invalid email or password."

    return render_template('auth/login.html')

@auth_bp.route('/logout')
def logout():
    session.pop('user_id', None)  # حذف بيانات الجلسة
    return redirect('/auth/login')  # يرجع المستخدم لصفحة تسجيل الدخول

@auth_bp.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session:
        return redirect('/auth/login')

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        cursor.execute("""
            UPDATE users
            SET username = %s, email = %s, password = %s
            WHERE id = %s
        """, (username, email, password, session['user_id']))

        conn.commit()
        conn.close()

        return redirect('/')

    cursor.execute("SELECT * FROM users WHERE id = %s", (session['user_id'],))
    user = cursor.fetchone()
    conn.close()

    return render_template('auth/edit_profile.html', user=user)

@auth_bp.route('/delete_account', methods=['POST'])
def delete_account():
    if 'user_id' not in session:
        return redirect('/auth/login')

    conn = get_connection()
    cursor = conn.cursor()

    # حذف المستخدم
    cursor.execute("DELETE FROM users WHERE id = %s", (session['user_id'],))
    conn.commit()
    conn.close()

    session.pop('user_id', None)

    return redirect('/')

@auth_bp.route('/download_report')
def download_report():
    if 'user_id' not in session:
        return redirect('/auth/login')

    path = generate_user_report(session['user_id'])
    return send_file(path, as_attachment=True)