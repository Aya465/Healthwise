from flask import Blueprint, render_template, request, redirect, session
from config import get_connection

symptom_bp = Blueprint('symptom', __name__, url_prefix='/symptom')

@symptom_bp.route('/add', methods=['GET', 'POST'])
def add_symptom():
    if 'user_id' not in session:
        return redirect('/auth/login')

    if request.method == 'POST':
        symptom_text = request.form['symptom_text']
        user_id = session['user_id']

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO symptoms (user_id, symptom_text) VALUES (%s, %s)", (user_id, symptom_text))
        conn.commit()
        conn.close()

        return redirect('/symptom/list')

    return render_template('symptoms/add_symptom.html')

@symptom_bp.route('/list')
def list_symptoms():
    if 'user_id' not in session:
        return redirect('/auth/login')

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM symptoms WHERE user_id = %s", (session['user_id'],))
    symptoms = cursor.fetchall()
    conn.close()

    return render_template('symptoms/list_symptoms.html', symptoms=symptoms)

@symptom_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/auth/login')

    conn = get_connection()
    cursor = conn.cursor()

    # عدد الأعراض
    cursor.execute("SELECT COUNT(*) as count FROM symptoms WHERE user_id = %s", (session['user_id'],))
    symptom_count = cursor.fetchone()['count']

    # عدد التوصيات
    cursor.execute("SELECT COUNT(*) as count FROM recommendations")
    recommendation_count = cursor.fetchone()['count']

    # اسم المستخدم
    cursor.execute("SELECT username FROM users WHERE id = %s", (session['user_id'],))
    username = cursor.fetchone()['username']

    conn.close()

    return render_template('symptoms/dashboard.html', symptom_count=symptom_count, recommendation_count=recommendation_count, username=username)