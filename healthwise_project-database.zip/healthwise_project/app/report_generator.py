from fpdf import FPDF
from config import get_connection
import arabic_reshaper
from bidi.algorithm import get_display
import os

class PDF(FPDF):
    def header(self):
        reshaped = arabic_reshaper.reshape("تقرير صحة المستخدم - HealthWise")
        bidi_text = get_display(reshaped)
        self.set_font('Amiri', '', 14)
        self.cell(0, 10, bidi_text, ln=True, align='C')

def generate_user_report(user_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    cursor.execute("SELECT * FROM symptoms WHERE user_id = %s", (user_id,))
    symptoms = cursor.fetchall()

    conn.close()

    pdf = PDF()
    pdf.add_page()

    # تسجيل الخط العربي
    font_path = os.path.abspath("app/fonts/Amiri-Regular.ttf")
    pdf.add_font('Amiri', '', font_path, uni=True)
    pdf.set_font('Amiri', '', 14)

    # معلومات المستخدم
    username = get_display(arabic_reshaper.reshape(f"الاسم: {user['username']}"))
    email = get_display(arabic_reshaper.reshape(f"البريد الإلكتروني: {user['email']}"))

    pdf.cell(0, 10, username, ln=True, align='R')
    pdf.cell(0, 10, email, ln=True, align='R')
    pdf.ln(10)

    title = get_display(arabic_reshaper.reshape("الأعراض المسجلة:"))
    pdf.cell(0, 10, title, ln=True, align='R')

    for symptom in symptoms:
        symptom_text = get_display(arabic_reshaper.reshape(f"- {symptom['symptom_text']} ({symptom['date_logged']})"))
        pdf.multi_cell(0, 10, symptom_text, align='R')

    output_dir = os.path.join("app", "static", "reports")
    os.makedirs(output_dir, exist_ok=True)

    file_path = os.path.join(output_dir, f"user_{user_id}_report.pdf")
    pdf.output(file_path)

    return file_path