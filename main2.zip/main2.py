from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from transformers import T5ForConditionalGeneration, T5Tokenizer
import torch
from pydantic import BaseModel
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI
app = FastAPI()

# CORS Configuration (Allow your frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development only
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load T5 Model and Tokenizer
model_name = r"G:\Healthwise_2\t5_fine_tuned_model"  # Your custom model path
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)

# Set model to evaluation mode
model.eval()


# Request model for proper JSON validation
class PredictionRequest(BaseModel):
    text: str


# Improved Prediction Endpoint
@app.post("/predict")
async def predict(request: PredictionRequest):
    try:
        logger.info(f"Received request with text: {request.text}")

        # Tokenize input with task-specific prefix
        inputs = tokenizer.encode(
            f"analyze: {request.text}",
            return_tensors="pt",
            max_length=512,
            truncation=True,
            padding="max_length"
        )

        # Generate response with improved parameters
        outputs = model.generate(
            inputs,
            max_length=200,
            num_beams=5,
            early_stopping=True,
            temperature=0.7,
            top_k=50,
            top_p=0.95
        )

        # Decode and clean response
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        logger.info(f"Generated response: {response}")

        return {"response": response}

    except Exception as e:
        logger.error(f"Error in prediction: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="An error occurred while processing your request"
        )


# Health Check Endpoint
@app.get("/")
async def health_check():
    return {
        "status": "Healthy",
        "model": model_name,
        "ready": True
    }


# New endpoint for model info
@app.get("/model-info")
async def model_info():
    return {
        "model_type": "T5",
        "model_path": model_name,
        "input_max_length": 512,
        "output_max_length": 200
    }






